<?php 

	include_once("conexao.php");

	$id = $_GET['id'];
	$edit_processa1 = "SELECT * FROM usuario WHERE id='$id' LIMIT 1";
	$edit_processa2 = mysqli_query($con,$edit_processa1);

	$row = mysqli_fetch_assoc($edit_processa2);

 ?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8">
		
		
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<title>Projeto - PC4</title>
		
			<link rel="stylesheet" href="css/bootstrap.min.css">
		
			<link rel="stylesheet" href="css/style.css">

	</head>
<body>
	<nav id="nav_top" class="navbar navbar-expand-md navbar-light bg-light fixed-top">
			<div class="container-fluid">
			    <a href="#" class="navbar-brand"  id="tt_nav">
			        <div>EDITAR USUÁRIO</div>
			    </a>  


	    </div>
	</nav>

	<section id="SEC_1">
		<div class="container">
		<div class="row">
				
<div class="col-lg-12">
	<form  action="editar.php" method="POST">
		<label id="form_label" >Foto</label>
		<br>
			<img src="img/avatar.png" class="rounded-circle"  id="avatar" alt="">
			<label for="upload" id="btn_modificar" class="btn btn-outline-dark">Modificar</label>
				<input id="upload" name="img" type="file" value="Modificar">

					  <div class="row" id="campos_form">
					  	<div class="col-md-6 col-lg-6"> 
					  		<label id="form_label">Nome</label> 
					           <input type="text" class="form form-control" name="nome" value="<?php echo $row['nome'];   ?>">
					  	</div>
					  	<div class="col-md-6 col-lg-6">
					           <label id="form_label">E-mail</label> 
					             <input type="mail" class="form form-control" name="email" value="<?php echo $row['email'];   ?>">  
				         </div>


				         <div class=" col-md-6 col-lg-6" id="seg_linha">
					  			<label id="form_label">Setor</label> 

					  			  <input type="mail" class="form form-control" name="setor" value="<?php echo $row['setor'];   ?>"> 
					
						</div>

						<div class=" col-md-6 col-lg-6" id="seg_linha">
								  <label id="form_label">Cargo</label> 

								 <input type="mail" class="form form-control" name="cargo" value="<?php echo $row['cargo'];   ?>"> 
								  
					
						</div>

						<div class="col-lg-6">
							  <label id="form_label">Função</label> 
							  <input type="mail" class="form form-control" name="funcao" value="<?php echo $row['func'];   ?>"> 
						
  					</div>

  					<div class="col-lg-6">
  						 <label id="form_label">Status</label>
  						 <input type="mail" class="form form-control" name="status" value="<?php echo $row['status'];   ?>"> 
					</div>

					<div class="col-lg-6">
  						<input type="hidden"  name="id" value="<?php echo $row['id']; ?>"> 
					</div>

					 <input type="hidden"  name="id" value="<?php echo $row['id']; ?>"> 

				</div>

						<footer id="nav_down" class="navbar navbar-expand-md navbar-light bg-light fixed-bottom">
							<div class="container-fluid">
							  
							    <a href="#" class="">
							     
							    </a>
							    <ul class="nav justify-content-end">
								  <li class="nav-item">
								    <input type="submit" id="btn_salvar"  value="Editar" class="btn btn-primary">
								  </li>
								</ul>


							   
					    </div>
					</footer>


					  </form>
					</div>			
			</div>
		</div>
	</section>
	
	<script src="js/jquery-3.3.1.slim.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
</html>
















 
<?php 

	$serv = "localhost";
	$user = "root";
	$pass = "";
	$db_name = "pc_4";

	$con = mysqli_connect($serv,$user,$pass,$db_name);

 ?>
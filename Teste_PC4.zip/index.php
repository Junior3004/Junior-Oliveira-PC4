<?php 
	session_start();
	require("conexao.php");
	 ?>

<!DOCTYPE html>
<html lang="pt-br">

	<head>
		<meta charset="UTF-8">
		
		
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<title>Projeto - PC4</title>
		
			<link rel="stylesheet" href="css/bootstrap.min.css">
		
			<link rel="stylesheet" href="css/style.css">

	</head>




<body>

	

	<nav id="nav_top" class="navbar navbar-expand-md navbar-light bg-light fixed-top">
			<div class="container-fluid">
			    <a href="#" class="navbar-brand"  id="tt_nav">
			        <div>CADASTRAR NOVO USUÁRIO</div>
			    </a>  


	    </div>
	</nav>

	<section id="SEC_1">
		<div class="container">
		<div class="row">
				
<div class="col-lg-12">
	<form  action="inserir.php" method="POST">
		<label id="form_label" >Foto</label>
		<br>
			<img src="img/avatar.png" class="rounded-circle"  id="avatar" alt="">
			<label for="upload" id="btn_modificar" class="btn btn-outline-dark">Modificar</label>
				<input id="upload" name="img" type="file" value="Modificar">

					  <div class="row" id="campos_form">
					  	<div class="col-md-6 col-lg-6"> 
					  		<label id="form_label">Nome</label> 
					           <input type="text" class="form form-control" name="nome" placeholder="Digite o nome" required="">
					  	</div>
					  	<div class="col-md-6 col-lg-6">
					           <label id="form_label">E-mail</label> 
					             <input type="mail" class="form form-control" name="email" placeholder="me@example.com"  required="">  
				         </div>


				         <div class=" col-md-6 col-lg-6" id="seg_linha">
					  			<label id="form_label">Setor</label> 
					  
						<div class="form-group">
						    <select class="form-control" id="exampleFormControlSelect1" name="setor" required=""  placeholder="me@example.com">
						      <option>Selecionar item</option>
						      <option>T.I</option>
						      <option>Financeiro</option>
						      <option>RH</option>
						      <option>Vendas</option>
						    </select>
						  </div>
						</div>

						<div class=" col-md-6 col-lg-6" id="seg_linha">
								  <label id="form_label">Cargo</label> 
								  
						<div class="form-group">
						    <select class="form-control" name="cargo" id="exampleFormControlSelect1" required="">
						       <option>Selecionar item</option>
						      <option>Gerente</option>
						      <option>Sub Gerente</option>
						      <option>Vendedor</option>
						    </select>
						  </div>
						</div>

						<div class="col-lg-6">
							  <label id="form_label">Função</label> 
							  
						<div class="form-group">
						    <select class="form-control" name="funcao" id="exampleFormControlSelect1" required="">
						       <option>Selecionar item</option>
						      <option>Admin</option>
						    </select>
						  </div>
  					</div>

  					<div class="col-lg-12">
  						 <label id="form_label">Status</label>
  						 <span> (<span style="color:red"><b>inativo</b></span> ou <span style="color:green"><b>Ativo</b></span>)</span>
						<main>
							<div class="liga-desliga">
								<input type="checkbox" value="ativo" name="status" class="liga-desliga__checkbox" id="liga-desliga" >
								<label for="liga-desliga" class="liga-desliga__botao"></label>
							</div>
						</main>	 
					</div>



				</div>

						<footer id="nav_down" class="navbar navbar-expand-md navbar-light bg-light fixed-bottom">
							<div class="container-fluid">
							  
							    <a href="#" class="">
							     
							    </a>
							    <ul class="nav justify-content-end">
								  <li class="nav-item">
								    <input type="submit" id="btn_salvar"  value="Salvar" class="btn btn-primary">
								  </li>
								</ul>


							   
					    </div>
					</footer>


					  </form>
					</div>			
			</div>
		</div>
	</section>
	

	 
			<a href=""></a>
		
		


		
			





	<script src="js/jquery-3.3.1.slim.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
</html>
<!DOCTYPE html>
<html lang="pt-br">

	<head>
		<meta charset="UTF-8">
		
		
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<title>Projeto - PC4</title>
		
			<link rel="stylesheet" href="css/bootstrap.min.css">
		
			<link rel="stylesheet" href="css/style.css">

	</head>




<body>


	<div class="container-fluid">
	<div class="row">
		<div class="col-lg-12">

					<table class='table'>
				  <thead class='thead' id='faixa_top'>
				    <tr>
				   <th scope='col'>NOME</th>
				   <th scope='col'>CARGO</th>
				   <th scope='col'>STATUS</th>
				   <th scope='col'>FUNÇÃO</th>
				   </tr>
				   </thead>
				   <tbody>
		
			<?php 
				require("conexao.php");

				$selec_1 = "SELECT * FROM usuario";
				$selec_2 = mysqli_query($con,$selec_1);
			
				
				while ($row = mysqli_fetch_assoc($selec_2)) {				
				   
						echo"<td><img src='". $row['img']."'> ". $row['nome'] . "</td>";
						echo"<td>". $row['cargo'] . "</td>";
						echo"<td>". $row['status'] . "</td>";
						echo"<td>". $row['func'] . "</td>";
						echo "<td><a href='edit_processa.php?id=".$row['id']."'>Editar</a></td> ";
						echo "</tr>";


				
					
				}

				



			 ?>

			</tbody>
			</table>
		</div>

		
		
	</div>
</div>



	<section>	

						<footer id="nav_down" class="navbar navbar-expand-md navbar-light bg-light fixed-bottom">
							<div class="container-fluid">
							  
							    <a href="#" class="">
							        
							    </a>
							    <ul class="nav justify-content-end">
								  <li class="nav-item">
								    <a href="index.php" id="btn_salvar" class="btn btn-primary">Novo</a>
								  </li>
								</ul>
							   
					    </div>
					</footer>


					  
					</div>			
		
	</section>

	

	 
			
		
		


		
			





	<script src="js/jquery-3.3.1.slim.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>
</html>
<?php 
	
	session_start();
	require("conexao.php");

	$img = $_POST['img'];
	$nome = $_POST['nome'];
	$email = $_POST['email'];
	$setor = $_POST['setor'];
	$cargo = $_POST['cargo'];
	$func = $_POST['funcao'];
	@$status = $_POST['status'];


	if (empty($img) && empty($nome) && empty($email) && empty($setor) && empty($cargo) && empty($func) && empty($status)) {
		header("Location:index.php");
	}


	if (empty($status)) {
		$status = "inativo";
		header("Location:index.php");
	}


	if (($setor == "Selecionar item") or ($cargo == "Selecionar item") or ($func == "Selecionar item")) {

		header("Location:index.php");
	}

	
		$insere_1 = "INSERT INTO usuario(img,nome,email,setor,cargo,func,status)VALUES('$img','$nome','$email','$setor','$cargo','$func','$status')";
	$insere_2 = mysqli_query($con,$insere_1);

	header("Location:index.php");

	/*

		if (mysqli_insert_id($con)) {
		
		$_SESSION['msg'] =  "
			<div class='alert alert-success' role='alert'>
			  <center>Cadastrado com sucesso!</center>
			</div>
			";

			header("Location:index.php");
	}

	else{
		$_SESSION['msg'] =  "
			<div class='alert alert-danger' role='alert'>
			  Não foi possível cadastrar!
			</div>
			";

			header("Location:index.php");
	}


	
	/*
	$insere_1 = "INSERT INTO usuario(img,nome,email,setor,cargo,func,status)VALUES('$img','$nome','$email','$setor','$cargo','$func','$status')";
	$insere_2 = mysqli_query($con,$insere_1);
	*/

 ?>
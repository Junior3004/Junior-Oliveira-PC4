<?php 

	include_once("conexao.php");

	$img = $_POST['img'];
	$nome = $_POST['nome'];
	$email = $_POST['email'];
	$setor = $_POST['setor'];
	$cargo = $_POST['cargo'];
	$func = $_POST['funcao'];
	$status = $_POST['status'];
	$id = $_POST['id'];

	echo $img ."<br>";
	echo $nome ."<br>";
	echo $email ."<br>";
	echo $setor ."<br>";
	echo $cargo ."<br>";
	echo $func ."<br>";
	echo $status ."<br>";
	echo $id ."<br>";

	

	$editar_1 = "UPDATE usuario SET
	img = '$img',
	nome = '$nome',
	email = '$email',
	setor = '$setor',
	cargo = '$cargo',
	func = '$func',
	status = '$status' WHERE id ='$id'
	";

	$editar_2 = mysqli_query($con,$editar_1);

	if (mysqli_affected_rows($con)) {
		header("Location:clientes.php");

	}
	else {
		header("Location:index.php");
	}


 ?>